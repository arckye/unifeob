class MaoDeObra(var nome: String, var horasTrabalhadas: Int, var precoPorHora: Int) {

}